﻿namespace Binary_Watch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.h2 = new System.Windows.Forms.Label();
            this.h1 = new System.Windows.Forms.Label();
            this.h4 = new System.Windows.Forms.Label();
            this.h8 = new System.Windows.Forms.Label();
            this.lblH = new System.Windows.Forms.Label();
            this.lblM = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.m8 = new System.Windows.Forms.Label();
            this.m4 = new System.Windows.Forms.Label();
            this.m1 = new System.Windows.Forms.Label();
            this.m2 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.m16 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.m32 = new System.Windows.Forms.Label();
            this.s32 = new System.Windows.Forms.Label();
            this.s16 = new System.Windows.Forms.Label();
            this.lblS = new System.Windows.Forms.Label();
            this.s8 = new System.Windows.Forms.Label();
            this.s4 = new System.Windows.Forms.Label();
            this.s1 = new System.Windows.Forms.Label();
            this.s2 = new System.Windows.Forms.Label();
            this.lblPeriod = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // h2
            // 
            this.h2.AutoSize = true;
            this.h2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.h2.ForeColor = System.Drawing.Color.DimGray;
            this.h2.Location = new System.Drawing.Point(442, 75);
            this.h2.Name = "h2";
            this.h2.Size = new System.Drawing.Size(42, 55);
            this.h2.TabIndex = 0;
            this.h2.Text = "•";
            this.h2.Click += new System.EventHandler(this.label1_Click);
            // 
            // h1
            // 
            this.h1.AutoSize = true;
            this.h1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.h1.ForeColor = System.Drawing.Color.DimGray;
            this.h1.Location = new System.Drawing.Point(522, 75);
            this.h1.Name = "h1";
            this.h1.Size = new System.Drawing.Size(42, 55);
            this.h1.TabIndex = 1;
            this.h1.Text = "•";
            // 
            // h4
            // 
            this.h4.AutoSize = true;
            this.h4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.h4.ForeColor = System.Drawing.Color.DimGray;
            this.h4.Location = new System.Drawing.Point(362, 75);
            this.h4.Name = "h4";
            this.h4.Size = new System.Drawing.Size(42, 55);
            this.h4.TabIndex = 2;
            this.h4.Text = "•";
            // 
            // h8
            // 
            this.h8.AutoSize = true;
            this.h8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.h8.ForeColor = System.Drawing.Color.DimGray;
            this.h8.Location = new System.Drawing.Point(282, 75);
            this.h8.Name = "h8";
            this.h8.Size = new System.Drawing.Size(42, 55);
            this.h8.TabIndex = 3;
            this.h8.Text = "•";
            // 
            // lblH
            // 
            this.lblH.AutoSize = true;
            this.lblH.Font = new System.Drawing.Font("Andalus", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblH.ForeColor = System.Drawing.Color.Black;
            this.lblH.Location = new System.Drawing.Point(12, 88);
            this.lblH.Name = "lblH";
            this.lblH.Size = new System.Drawing.Size(92, 41);
            this.lblH.TabIndex = 9;
            this.lblH.Text = "H : 00";
            // 
            // lblM
            // 
            this.lblM.AutoSize = true;
            this.lblM.Font = new System.Drawing.Font("Andalus", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblM.ForeColor = System.Drawing.Color.Black;
            this.lblM.Location = new System.Drawing.Point(9, 140);
            this.lblM.Name = "lblM";
            this.lblM.Size = new System.Drawing.Size(97, 41);
            this.lblM.TabIndex = 18;
            this.lblM.Text = "M : 00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Andalus", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(284, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 41);
            this.label2.TabIndex = 17;
            this.label2.Text = "8";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Andalus", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(364, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 41);
            this.label3.TabIndex = 16;
            this.label3.Text = "4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Andalus", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(524, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 41);
            this.label4.TabIndex = 15;
            this.label4.Text = "1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Andalus", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(444, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 41);
            this.label10.TabIndex = 14;
            this.label10.Text = "2";
            // 
            // m8
            // 
            this.m8.AutoSize = true;
            this.m8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m8.ForeColor = System.Drawing.Color.DimGray;
            this.m8.Location = new System.Drawing.Point(282, 130);
            this.m8.Name = "m8";
            this.m8.Size = new System.Drawing.Size(42, 55);
            this.m8.TabIndex = 13;
            this.m8.Text = "•";
            // 
            // m4
            // 
            this.m4.AutoSize = true;
            this.m4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m4.ForeColor = System.Drawing.Color.DimGray;
            this.m4.Location = new System.Drawing.Point(362, 130);
            this.m4.Name = "m4";
            this.m4.Size = new System.Drawing.Size(42, 55);
            this.m4.TabIndex = 12;
            this.m4.Text = "•";
            // 
            // m1
            // 
            this.m1.AutoSize = true;
            this.m1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m1.ForeColor = System.Drawing.Color.DimGray;
            this.m1.Location = new System.Drawing.Point(522, 130);
            this.m1.Name = "m1";
            this.m1.Size = new System.Drawing.Size(42, 55);
            this.m1.TabIndex = 11;
            this.m1.Text = "•";
            // 
            // m2
            // 
            this.m2.AutoSize = true;
            this.m2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m2.ForeColor = System.Drawing.Color.DimGray;
            this.m2.Location = new System.Drawing.Point(442, 130);
            this.m2.Name = "m2";
            this.m2.Size = new System.Drawing.Size(42, 55);
            this.m2.TabIndex = 10;
            this.m2.Text = "•";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Andalus", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(189, 35);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 41);
            this.label15.TabIndex = 20;
            this.label15.Text = "16";
            // 
            // m16
            // 
            this.m16.AutoSize = true;
            this.m16.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m16.ForeColor = System.Drawing.Color.DimGray;
            this.m16.Location = new System.Drawing.Point(202, 127);
            this.m16.Name = "m16";
            this.m16.Size = new System.Drawing.Size(42, 55);
            this.m16.TabIndex = 19;
            this.m16.Text = "•";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Andalus", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(119, 33);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 41);
            this.label11.TabIndex = 22;
            this.label11.Text = "32";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // m32
            // 
            this.m32.AutoSize = true;
            this.m32.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m32.ForeColor = System.Drawing.Color.DimGray;
            this.m32.Location = new System.Drawing.Point(130, 130);
            this.m32.Name = "m32";
            this.m32.Size = new System.Drawing.Size(42, 55);
            this.m32.TabIndex = 21;
            this.m32.Text = "•";
            // 
            // s32
            // 
            this.s32.AutoSize = true;
            this.s32.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s32.ForeColor = System.Drawing.Color.DimGray;
            this.s32.Location = new System.Drawing.Point(130, 185);
            this.s32.Name = "s32";
            this.s32.Size = new System.Drawing.Size(42, 55);
            this.s32.TabIndex = 31;
            this.s32.Text = "•";
            // 
            // s16
            // 
            this.s16.AutoSize = true;
            this.s16.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s16.ForeColor = System.Drawing.Color.DimGray;
            this.s16.Location = new System.Drawing.Point(200, 185);
            this.s16.Name = "s16";
            this.s16.Size = new System.Drawing.Size(42, 55);
            this.s16.TabIndex = 30;
            this.s16.Text = "•";
            // 
            // lblS
            // 
            this.lblS.AutoSize = true;
            this.lblS.Font = new System.Drawing.Font("Andalus", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblS.ForeColor = System.Drawing.Color.Black;
            this.lblS.Location = new System.Drawing.Point(20, 193);
            this.lblS.Name = "lblS";
            this.lblS.Size = new System.Drawing.Size(85, 41);
            this.lblS.TabIndex = 29;
            this.lblS.Text = "S : 00";
            // 
            // s8
            // 
            this.s8.AutoSize = true;
            this.s8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s8.ForeColor = System.Drawing.Color.DimGray;
            this.s8.Location = new System.Drawing.Point(282, 185);
            this.s8.Name = "s8";
            this.s8.Size = new System.Drawing.Size(42, 55);
            this.s8.TabIndex = 28;
            this.s8.Text = "•";
            // 
            // s4
            // 
            this.s4.AutoSize = true;
            this.s4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s4.ForeColor = System.Drawing.Color.DimGray;
            this.s4.Location = new System.Drawing.Point(362, 185);
            this.s4.Name = "s4";
            this.s4.Size = new System.Drawing.Size(42, 55);
            this.s4.TabIndex = 27;
            this.s4.Text = "•";
            // 
            // s1
            // 
            this.s1.AutoSize = true;
            this.s1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s1.ForeColor = System.Drawing.Color.DimGray;
            this.s1.Location = new System.Drawing.Point(522, 185);
            this.s1.Name = "s1";
            this.s1.Size = new System.Drawing.Size(42, 55);
            this.s1.TabIndex = 26;
            this.s1.Text = "•";
            // 
            // s2
            // 
            this.s2.AutoSize = true;
            this.s2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s2.ForeColor = System.Drawing.Color.DimGray;
            this.s2.Location = new System.Drawing.Point(442, 185);
            this.s2.Name = "s2";
            this.s2.Size = new System.Drawing.Size(42, 55);
            this.s2.TabIndex = 25;
            this.s2.Text = "•";
            // 
            // lblPeriod
            // 
            this.lblPeriod.AutoSize = true;
            this.lblPeriod.Font = new System.Drawing.Font("Andalus", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeriod.Location = new System.Drawing.Point(27, 36);
            this.lblPeriod.Name = "lblPeriod";
            this.lblPeriod.Size = new System.Drawing.Size(53, 38);
            this.lblPeriod.TabIndex = 32;
            this.lblPeriod.Text = "AM";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(590, 253);
            this.Controls.Add(this.lblPeriod);
            this.Controls.Add(this.s32);
            this.Controls.Add(this.s16);
            this.Controls.Add(this.lblS);
            this.Controls.Add(this.s8);
            this.Controls.Add(this.s4);
            this.Controls.Add(this.s1);
            this.Controls.Add(this.s2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.m32);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.m16);
            this.Controls.Add(this.lblM);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.m8);
            this.Controls.Add(this.m4);
            this.Controls.Add(this.m1);
            this.Controls.Add(this.m2);
            this.Controls.Add(this.lblH);
            this.Controls.Add(this.h8);
            this.Controls.Add(this.h4);
            this.Controls.Add(this.h1);
            this.Controls.Add(this.h2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Binary Watch";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label h2;
        private System.Windows.Forms.Label h1;
        private System.Windows.Forms.Label h4;
        private System.Windows.Forms.Label h8;
        private System.Windows.Forms.Label lblH;
        private System.Windows.Forms.Label lblM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label m8;
        private System.Windows.Forms.Label m4;
        private System.Windows.Forms.Label m1;
        private System.Windows.Forms.Label m2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label m16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label m32;
        private System.Windows.Forms.Label s32;
        private System.Windows.Forms.Label s16;
        private System.Windows.Forms.Label s8;
        private System.Windows.Forms.Label s4;
        private System.Windows.Forms.Label s1;
        private System.Windows.Forms.Label s2;
        private System.Windows.Forms.Label lblS;
        private System.Windows.Forms.Label lblPeriod;
    }
}

