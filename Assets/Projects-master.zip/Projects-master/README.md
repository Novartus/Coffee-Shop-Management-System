# List of C# Projects

## [1- Bracode :](C%23%20Projects/1-%20Barcode)
       Convert Text to Baracode.
       
![Barcode](/Graphics/Resources/Barcode.PNG)

## [2- Digital Watch :](C%23%20Projects/2-%20Digital%20Watch)
       GUI For getting current time continuously.
       
![Barcode](/Graphics/Resources/digital_watch.PNG)

## [3- Binary Watch](/C%23%20Projects/3-%20Binary%20Watch)
       GUI For getting current time continuously and repesent it as binary.
       
![Barcode](/Graphics/Resources/binary_watch.PNG)

## [4- Graphical Digital Watch](/C%23%20Projects/4-%20Graphical%20Digital%20watch)
        GUI For getting current time continuously and repesent it with graphical images.
       
![Barcode](/Graphics/Resources/graphical_digital_watch.PNG)

## [5- Image Resize](/C%23%20Projects/5-%20Image%20Resize)
       Resize images into bigger and lower size and you can change extention.
       
![Barcode](/Graphics/Resources/image_resize.PNG)

## [6- Picture Puzzle Game](/C%23%20Projects/6-%20Picture%20Puzzle%20Game)
       image divided into parts Randomly and player can swap part with Empty part to get the orignal image.
       
![Barcode](/Graphics/Resources/puzzle_game.PNG)

## [7- Snake Game](/C%23%20Projects/7-%20Snake%20Game)
      Snake Game, everyone knows this game.
       
![Barcode](/Graphics/Resources/snake_game.PNG)
