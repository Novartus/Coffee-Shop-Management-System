﻿namespace RoundButtonDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button_WOC12 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC9 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC6 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC8 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC10 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC3 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC7 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC5 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC4 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC2 = new ePOSOne.btnProduct.Button_WOC();
            this.button_WOC1 = new ePOSOne.btnProduct.Button_WOC();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(492, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(287, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "C# Ui Academy";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(495, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(278, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "We Create, We Design, We Develop";
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPassword.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(422, 183);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(340, 41);
            this.txtPassword.TabIndex = 2;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.Enter += new System.EventHandler(this.txtPassword_Enter);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(303, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "Password:";
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(768, 183);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 41);
            this.button1.TabIndex = 3;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Georgia", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(1106, 1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(77, 50);
            this.button2.TabIndex = 3;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_WOC12
            // 
            this.button_WOC12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC12.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC12.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC12.FlatAppearance.BorderSize = 0;
            this.button_WOC12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC12.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC12.Location = new System.Drawing.Point(574, 518);
            this.button_WOC12.Name = "button_WOC12";
            this.button_WOC12.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC12.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC12.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC12.Size = new System.Drawing.Size(299, 82);
            this.button_WOC12.TabIndex = 1;
            this.button_WOC12.Text = "Clear";
            this.button_WOC12.TextColor = System.Drawing.Color.White;
            this.button_WOC12.UseVisualStyleBackColor = true;
            this.button_WOC12.Click += new System.EventHandler(this.button_WOC12_Click);
            // 
            // button_WOC9
            // 
            this.button_WOC9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC9.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC9.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC9.FlatAppearance.BorderSize = 0;
            this.button_WOC9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC9.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC9.Location = new System.Drawing.Point(728, 426);
            this.button_WOC9.Name = "button_WOC9";
            this.button_WOC9.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC9.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC9.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC9.Size = new System.Drawing.Size(145, 82);
            this.button_WOC9.TabIndex = 1;
            this.button_WOC9.Text = "9";
            this.button_WOC9.TextColor = System.Drawing.Color.White;
            this.button_WOC9.UseVisualStyleBackColor = true;
            this.button_WOC9.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // button_WOC6
            // 
            this.button_WOC6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC6.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC6.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC6.FlatAppearance.BorderSize = 0;
            this.button_WOC6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC6.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC6.Location = new System.Drawing.Point(728, 334);
            this.button_WOC6.Name = "button_WOC6";
            this.button_WOC6.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC6.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC6.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC6.Size = new System.Drawing.Size(145, 82);
            this.button_WOC6.TabIndex = 1;
            this.button_WOC6.Text = "6";
            this.button_WOC6.TextColor = System.Drawing.Color.White;
            this.button_WOC6.UseVisualStyleBackColor = true;
            this.button_WOC6.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // button_WOC8
            // 
            this.button_WOC8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC8.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC8.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC8.FlatAppearance.BorderSize = 0;
            this.button_WOC8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC8.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC8.Location = new System.Drawing.Point(574, 425);
            this.button_WOC8.Name = "button_WOC8";
            this.button_WOC8.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC8.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC8.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC8.Size = new System.Drawing.Size(145, 82);
            this.button_WOC8.TabIndex = 1;
            this.button_WOC8.Text = "8";
            this.button_WOC8.TextColor = System.Drawing.Color.White;
            this.button_WOC8.UseVisualStyleBackColor = true;
            this.button_WOC8.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // button_WOC10
            // 
            this.button_WOC10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC10.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC10.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC10.FlatAppearance.BorderSize = 0;
            this.button_WOC10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC10.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC10.Location = new System.Drawing.Point(421, 518);
            this.button_WOC10.Name = "button_WOC10";
            this.button_WOC10.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC10.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC10.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC10.Size = new System.Drawing.Size(145, 82);
            this.button_WOC10.TabIndex = 1;
            this.button_WOC10.Text = "0";
            this.button_WOC10.TextColor = System.Drawing.Color.White;
            this.button_WOC10.UseVisualStyleBackColor = true;
            this.button_WOC10.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // button_WOC3
            // 
            this.button_WOC3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC3.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC3.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC3.FlatAppearance.BorderSize = 0;
            this.button_WOC3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC3.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC3.Location = new System.Drawing.Point(728, 241);
            this.button_WOC3.Name = "button_WOC3";
            this.button_WOC3.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC3.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC3.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC3.Size = new System.Drawing.Size(145, 82);
            this.button_WOC3.TabIndex = 1;
            this.button_WOC3.Text = "3";
            this.button_WOC3.TextColor = System.Drawing.Color.White;
            this.button_WOC3.UseVisualStyleBackColor = true;
            this.button_WOC3.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // button_WOC7
            // 
            this.button_WOC7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC7.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC7.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC7.FlatAppearance.BorderSize = 0;
            this.button_WOC7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC7.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC7.Location = new System.Drawing.Point(421, 426);
            this.button_WOC7.Name = "button_WOC7";
            this.button_WOC7.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC7.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC7.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC7.Size = new System.Drawing.Size(145, 82);
            this.button_WOC7.TabIndex = 1;
            this.button_WOC7.Text = "7";
            this.button_WOC7.TextColor = System.Drawing.Color.White;
            this.button_WOC7.UseVisualStyleBackColor = true;
            this.button_WOC7.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // button_WOC5
            // 
            this.button_WOC5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC5.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC5.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC5.FlatAppearance.BorderSize = 0;
            this.button_WOC5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC5.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC5.Location = new System.Drawing.Point(574, 333);
            this.button_WOC5.Name = "button_WOC5";
            this.button_WOC5.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC5.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC5.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC5.Size = new System.Drawing.Size(145, 82);
            this.button_WOC5.TabIndex = 1;
            this.button_WOC5.Text = "5";
            this.button_WOC5.TextColor = System.Drawing.Color.White;
            this.button_WOC5.UseVisualStyleBackColor = true;
            this.button_WOC5.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // button_WOC4
            // 
            this.button_WOC4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC4.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC4.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC4.FlatAppearance.BorderSize = 0;
            this.button_WOC4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC4.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC4.Location = new System.Drawing.Point(421, 334);
            this.button_WOC4.Name = "button_WOC4";
            this.button_WOC4.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC4.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC4.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC4.Size = new System.Drawing.Size(145, 82);
            this.button_WOC4.TabIndex = 1;
            this.button_WOC4.Text = "4";
            this.button_WOC4.TextColor = System.Drawing.Color.White;
            this.button_WOC4.UseVisualStyleBackColor = true;
            this.button_WOC4.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // button_WOC2
            // 
            this.button_WOC2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC2.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC2.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC2.FlatAppearance.BorderSize = 0;
            this.button_WOC2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC2.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC2.Location = new System.Drawing.Point(574, 240);
            this.button_WOC2.Name = "button_WOC2";
            this.button_WOC2.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC2.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC2.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC2.Size = new System.Drawing.Size(145, 82);
            this.button_WOC2.TabIndex = 1;
            this.button_WOC2.Text = "2";
            this.button_WOC2.TextColor = System.Drawing.Color.White;
            this.button_WOC2.UseVisualStyleBackColor = true;
            this.button_WOC2.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // button_WOC1
            // 
            this.button_WOC1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_WOC1.BorderColor = System.Drawing.Color.Orange;
            this.button_WOC1.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC1.FlatAppearance.BorderSize = 0;
            this.button_WOC1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_WOC1.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_WOC1.Location = new System.Drawing.Point(421, 241);
            this.button_WOC1.Name = "button_WOC1";
            this.button_WOC1.OnHoverBorderColor = System.Drawing.Color.Orange;
            this.button_WOC1.OnHoverButtonColor = System.Drawing.Color.Orange;
            this.button_WOC1.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.button_WOC1.Size = new System.Drawing.Size(145, 82);
            this.button_WOC1.TabIndex = 1;
            this.button_WOC1.Text = "1";
            this.button_WOC1.TextColor = System.Drawing.Color.White;
            this.button_WOC1.UseVisualStyleBackColor = true;
            this.button_WOC1.Click += new System.EventHandler(this.button_WOC1_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(1184, 681);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.button_WOC12);
            this.Controls.Add(this.button_WOC9);
            this.Controls.Add(this.button_WOC6);
            this.Controls.Add(this.button_WOC8);
            this.Controls.Add(this.button_WOC10);
            this.Controls.Add(this.button_WOC3);
            this.Controls.Add(this.button_WOC7);
            this.Controls.Add(this.button_WOC5);
            this.Controls.Add(this.button_WOC4);
            this.Controls.Add(this.button_WOC2);
            this.Controls.Add(this.button_WOC1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private ePOSOne.btnProduct.Button_WOC button_WOC1;
        private ePOSOne.btnProduct.Button_WOC button_WOC2;
        private ePOSOne.btnProduct.Button_WOC button_WOC3;
        private ePOSOne.btnProduct.Button_WOC button_WOC4;
        private ePOSOne.btnProduct.Button_WOC button_WOC5;
        private ePOSOne.btnProduct.Button_WOC button_WOC6;
        private ePOSOne.btnProduct.Button_WOC button_WOC7;
        private ePOSOne.btnProduct.Button_WOC button_WOC8;
        private ePOSOne.btnProduct.Button_WOC button_WOC9;
        private ePOSOne.btnProduct.Button_WOC button_WOC10;
        private ePOSOne.btnProduct.Button_WOC button_WOC12;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

